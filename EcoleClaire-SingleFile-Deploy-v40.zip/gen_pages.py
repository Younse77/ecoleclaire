#!/usr/bin/env python3
# Génère une page HTML statique par collège/lycée — optimisée SEO + citation IA (GEO)
import json, os, re, html as H

DATA = '/home/claude/ec/ecoles-france.json'
OUT  = '/home/claude/ec/pages_etablissements'
DOMAIN = 'https://REMPLACER-PAR-VOTRE-DOMAINE'  # à éditer après choix du domaine

TYPE = {'C':'Collège','L':'Lycée'}
STAT = {'P':'Public','V':'Privé','A':'Associatif'}

def slug(s):
    s = s.lower()
    repl = {'à':'a','â':'a','ä':'a','é':'e','è':'e','ê':'e','ë':'e','î':'i','ï':'i',
            'ô':'o','ö':'o','û':'u','ù':'u','ü':'u','ç':'c','œ':'oe',"'":'-','’':'-'}
    for k,v in repl.items(): s = s.replace(k,v)
    s = re.sub(r'[^a-z0-9]+','-',s).strip('-')
    return re.sub(r'-+','-',s)

def esc(x): return H.escape(str(x)) if x is not None else ''

def pauvre(s):
    return not any(s.get(k) not in (None,'',[]) for k in ['r','v','i','te','l'])

def page(s):
    typ = TYPE.get(s.get('t'),'Établissement')
    nom = s.get('n','')
    commune = s.get('c','')
    stat = STAT.get(s.get('st'),'')
    uai = s.get('u','')
    cp = s.get('cp','')
    sl = slug(nom+'-'+commune)+'-'+uai.lower()
    url = DOMAIN+'/ecole/'+sl+'.html'

    # Indicateurs réels (clés courtes)
    r = s.get('r'); v = s.get('v'); i = s.get('i'); lv = s.get('l'); web = s.get('w')
    mention = s.get('mention'); txacces = s.get('txAcces')
    te = s.get('te'); o = s.get('o') or {}

    # Titre + description = formulations que les parents tapent
    title = f"{nom} ({commune}) — résultats, avis et infos | ÉcoleClaire"
    desc_bits = [f"{typ} {stat.lower()} à {commune}"]
    if r is not None: desc_bits.append(f"{r}% de réussite au brevet")
    if v is not None: desc_bits.append(f"valeur ajoutée {'+' if float(v)>=0 else ''}{v}")
    if i is not None: desc_bits.append(f"IPS {round(i)}")
    desc = '. '.join(desc_bits) + ". Données officielles de l'Éducation nationale."

    # Paragraphe d'introduction "answer-first" (40-60 mots, ce que les IA extraient)
    intro = f"{nom} est un {typ.lower()} {stat.lower()} situé à {commune} ({cp}). "
    facts = []
    if r is not None: facts.append(f"Son taux de réussite au brevet est de {r}%")
    if v is not None: facts.append(f"sa valeur ajoutée est de {'+' if float(v)>=0 else ''}{v}")
    if i is not None: facts.append(f"son indice de position sociale (IPS) est de {round(i)}")
    if facts: intro += ', '.join(facts) + ". "
    intro += "Ces données proviennent des publications officielles de l'Éducation nationale."
    if pauvre(s):
        intro = f"{nom} est un {typ.lower()} {stat.lower()} situé à {commune} ({cp}). Les indicateurs détaillés (résultats, IPS, valeur ajoutée) ne sont pas encore publiés par l'Éducation nationale pour cet établissement — souvent une structure récente ou de petite taille."

    # Lignes du tableau
    rows = ''
    def row(k,val): return f'<tr><th scope="row">{k}</th><td>{val}</td></tr>'
    rows += row('Type', f'{typ} {stat.lower()}')
    rows += row('Commune', f'{esc(commune)} ({esc(cp)})')
    rlbl = 'Réussite au bac' if s.get('t')=='L' else 'Réussite au brevet'
    if r is not None: rows += row(rlbl, f'{r}%')
    if v is not None: rows += row('Valeur ajoutée', f"{'+' if float(v)>=0 else ''}{v}")
    if mention is not None: rows += row('Taux de mention', f'{mention}%')
    if txacces is not None: rows += row("Taux d'accès au bac", f'{txacces}%')
    if i is not None: rows += row('IPS (mixité sociale)', round(i))
    if te is not None: rows += row('Effectif', f'{te} élèves')
    if lv: rows += row('Langues', esc(lv))
    secs = []
    if o.get('sectionEuro'): secs.append('Européenne')
    if o.get('sectionInter'): secs.append('Internationale')
    if o.get('sport'): secs.append('Sport')
    if secs: rows += row('Sections', ', '.join(secs))
    if o.get('cantine'): rows += row('Cantine', 'Oui')
    if o.get('internat'): rows += row('Internat', 'Oui')
    if o.get('ulis'): rows += row('ULIS (inclusion)', 'Oui')

    # JSON-LD School spécifique
    jsonld = {
        "@context":"https://schema.org","@type":"School","name":nom,
        "address":{"@type":"PostalAddress","addressLocality":commune,"postalCode":cp,"addressCountry":"FR"},
    }
    if web: jsonld["url"] = web
    if s.get('la') and s.get('lo'):
        jsonld["geo"]={"@type":"GeoCoordinates","latitude":s['la'],"longitude":s['lo']}

    web_html = f'<p><a href="{esc(web)}" rel="noopener">Site officiel de l\'établissement</a></p>' if web else ''

    return sl, f'''<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>{esc(title)}</title>
<meta name="description" content="{esc(desc)}"/>
<link rel="canonical" href="{esc(url)}"/>
<meta property="og:type" content="website"/>
<meta property="og:title" content="{esc(nom)} ({esc(commune)})"/>
<meta property="og:description" content="{esc(desc)}"/>
<meta name="robots" content="index, follow"/>
<script type="application/ld+json">{json.dumps(jsonld,ensure_ascii=False)}</script>
<style>
body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:760px;margin:0 auto;padding:24px 18px;color:#1A2233;line-height:1.6}}
a{{color:#2563EB}} h1{{font-size:1.5rem;letter-spacing:-.02em}} h2{{font-size:1.1rem;margin-top:28px}}
table{{width:100%;border-collapse:collapse;margin:12px 0}} th,td{{text-align:left;padding:9px 0;border-bottom:1px solid #E5E9F0;font-size:.95rem}}
th[scope=row]{{color:#5B6678;font-weight:500;width:45%}}
.src{{font-size:.8rem;color:#7A8699;margin-top:24px;border-top:1px solid #E5E9F0;padding-top:12px}}
.cta{{display:inline-block;background:#2563EB;color:#fff;text-decoration:none;padding:11px 18px;border-radius:10px;font-weight:600;margin-top:14px}}
nav{{font-size:.85rem;color:#7A8699;margin-bottom:16px}}
</style>
</head>
<body>
<nav><a href="{DOMAIN}/">ÉcoleClaire</a> › {esc(typ)}s › {esc(commune)}</nav>
<h1>{esc(nom)}</h1>
<p>{esc(intro)}</p>

<h2>Indicateurs officiels ({esc(typ)} à {esc(commune)})</h2>
<table>{rows}</table>
{web_html}

<h2>Comparer avec les établissements proches</h2>
<p>Retrouvez ce {esc(typ.lower())} et comparez-le avec les autres établissements de {esc(commune)} et des environs sur ÉcoleClaire, à partir des données officielles de l'Éducation nationale.</p>
<a class="cta" href="{DOMAIN}/#ecole={esc(uai)}">Voir sur la carte et comparer →</a>

<h2>Questions fréquentes</h2>
<h3>Quel est le taux de réussite de {esc(nom)} ?</h3>
<p>{("Le taux de réussite au brevet de "+esc(nom)+" est de "+str(r)+"%.") if r is not None else "Le taux de réussite de cet établissement n'est pas disponible dans les données officielles."}</p>
<h3>{esc(nom)} est-il public ou privé ?</h3>
<p>{esc(nom)} est un établissement {esc(stat.lower())}.</p>

<p class="src">📊 Données officielles de l'Éducation nationale (rentrée 2024), vérifiables et mises à jour annuellement. ÉcoleClaire n'héberge pas d'avis et n'invente aucun chiffre. Pour une information à jour (places, projet pédagogique), contactez directement l'établissement.</p>
</body>
</html>'''

def main():
    os.makedirs(OUT, exist_ok=True)
    data = json.load(open(DATA, encoding='utf-8'))
    cible = [s for s in data if s.get('t') in ('C','L')]
    sitemap = ['<?xml version="1.0" encoding="UTF-8"?>',
               '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
               f'  <url><loc>{DOMAIN}/</loc><priority>1.0</priority></url>']
    n = 0
    for s in cible:
        sl, htmlc = page(s)
        with open(os.path.join(OUT, sl+'.html'), 'w', encoding='utf-8') as f:
            f.write(htmlc)
        if not pauvre(s):
            sitemap.append(f'  <url><loc>{DOMAIN}/ecole/{sl}.html</loc><changefreq>yearly</changefreq><priority>0.7</priority></url>')
        n += 1
    sitemap.append('</urlset>')
    with open('/home/claude/ec/sitemap.xml','w',encoding='utf-8') as f:
        f.write('\n'.join(sitemap))
    print(f'{n} pages générées dans {OUT}')
    print(f'sitemap.xml mis à jour ({n+1} URLs)')

if __name__ == '__main__':
    main()
