# FAQ — ÉcoleClaire

*Foire aux questions pour les parents. Réponses claires, honnêtes, sans jargon inutile.*

---

## À quoi sert ÉcoleClaire ?

ÉcoleClaire vous aide à trouver et comparer les écoles, collèges et lycées proches de chez vous, à partir des **données officielles de l'Éducation nationale**. Vous entrez votre ville ou votre adresse, et vous voyez les établissements autour de vous sur une carte, avec leurs vrais indicateurs : réussite, mixité sociale, taux d'encadrement, langues, options… Vous comparez ensuite selon **vos** critères.

## C'est gratuit ?

Oui, entièrement gratuit. Pas de compte obligatoire, pas de publicité, pas de revente de vos données.

## D'où viennent les données ?

Elles proviennent des bases publiques officielles, principalement de l'**Éducation nationale** (rentrée 2024) : résultats au brevet, indice de position sociale (IPS), valeur ajoutée, effectifs, langues, sections, éducation prioritaire. Ces données sont vérifiables et mises à jour chaque année. ÉcoleClaire n'invente aucun chiffre.

## En quoi est-ce mieux que de demander à ChatGPT ?

C'est une question légitime. Trois différences importantes :

D'abord, la **fiabilité**. Une IA généraliste comme ChatGPT peut inventer des chiffres, citer des classements qui n'existent pas, ou se baser sur des informations périmées. Pour un choix qui engage l'avenir de votre enfant, ÉcoleClaire s'appuie uniquement sur des données officielles sourcées.

Ensuite, la **proximité réelle**. ÉcoleClaire calcule la distance et le temps de trajet exacts depuis votre adresse, sur une carte. Une IA ne connaît pas précisément l'école située à 800 mètres de chez vous.

Enfin, ÉcoleClaire ne prétend pas désigner « la meilleure école ». Parce qu'elle n'existe pas — voir la question suivante.

## Quelle est la meilleure école près de chez moi ?

Il n'y a pas de réponse universelle, et tout site ou outil qui prétend le contraire vous induit en erreur. La « meilleure » école dépend de **votre enfant et de vos priorités** : proximité, résultats, petites classes, mixité, langue enseignée, ambiance… Une école idéale pour un enfant timide n'est pas la même que pour un enfant qui s'ennuie en classe. ÉcoleClaire ne vous impose pas un verdict : il vous donne les informations et un conseiller pour trouver **votre** meilleure école.

## C'est quoi l'IPS ?

L'IPS (Indice de Position Sociale) reflète le milieu social des familles d'un établissement, sur une échelle d'environ 50 à 150. **Ce n'est pas une note de qualité** : c'est un repère de mixité. Un IPS modéré associé à une bonne valeur ajoutée signale souvent une école qui fait réellement progresser ses élèves. Regardez les deux ensemble plutôt que l'IPS seul.

## C'est quoi la « valeur ajoutée » ?

Elle compare les résultats réels d'un établissement à ceux qu'on pouvait attendre vu le profil de ses élèves. Une valeur positive (+) signifie que l'établissement fait **mieux qu'attendu** : il fait progresser ses élèves. C'est souvent plus parlant que le taux de réussite brut, qui dépend beaucoup du public accueilli.

## Pourquoi n'y a-t-il pas de résultats pour les écoles primaires et maternelles ?

Parce qu'ils n'existent pas publiquement, par école. C'est un choix de l'État : les écoles du premier degré ne sont pas classées individuellement, pour éviter de mettre en concurrence de jeunes enfants. Les évaluations CP/CE1 existent mais ne sont publiées qu'au niveau départemental. Pour ces écoles, ÉcoleClaire affiche donc ce qui existe vraiment : taux d'encadrement, mixité (IPS), taille de l'école, éducation prioritaire, accueil des moins de 3 ans.

## Pourquoi je ne vois pas d'avis de parents ?

ÉcoleClaire n'héberge pas d'avis. Les avis en ligne sont difficiles à vérifier et peuvent être manipulés ou injustes. Nous préférons vous donner des données objectives. Vous pouvez toutefois consulter les avis Google directement depuis chaque fiche, via un lien.

## Pourquoi il n'y a pas de photo des écoles ?

Il n'existe pas de base publique et gratuite de photos d'écoles. Plutôt que d'afficher des images non fiables ou payantes, nous utilisons une vignette illustrée par type d'établissement.

## Comment connaître les frais d'une école privée ?

Aucune base officielle ne publie les tarifs des écoles privées : chaque établissement fixe ses prix librement. ÉcoleClaire affiche donc une **fourchette indicative** par niveau (pour le privé sous contrat) — à confirmer directement auprès de l'établissement. Le privé hors contrat peut être bien plus cher.

## Comment fonctionne le conseiller ?

Le conseiller s'appuie sur les écoles trouvées autour de vous et sur vos favoris. Vous pouvez lui poser une question en langage naturel (« un collège proche avec une bonne réussite et de l'allemand », « mon enfant est timide, je cherche une petite structure »). Il analyse les établissements réels et vous recommande ceux qui correspondent, en expliquant pourquoi. Il ne remplace pas votre jugement : c'est une aide à la décision.

## Mon enfant subit du harcèlement, que faire ?

ÉcoleClaire propose une page dédiée avec les numéros d'aide officiels : le **3018** (harcèlement et cyberharcèlement, gratuit et anonyme) et le **119** (enfance en danger). Toutes les écoles disposent aujourd'hui d'une équipe formée (programme pHARe). En cas de danger immédiat, composez le 17 (police) ou le 15 (SAMU). ÉcoleClaire ne traite pas les signalements et n'héberge aucune donnée personnelle.

## Mes recherches et favoris sont-ils privés ?

Oui. Vos favoris et préférences restent sur votre appareil. ÉcoleClaire ne crée pas de profil et ne partage rien.

## Les données sont-elles toujours à jour ?

Les données officielles sont mises à jour une fois par an, à la rentrée. ÉcoleClaire reflète la dernière publication disponible. Pour une information ponctuelle (place disponible, projet pédagogique, tarif exact), contactez directement l'établissement ou la mairie.

## Je pense qu'une information est erronée. Que faire ?

Les chiffres proviennent des bases officielles. S'ils vous semblent inexacts, ils peuvent dater de la dernière publication annuelle, ou l'établissement n'a pas transmis la donnée. Le plus sûr est de vérifier auprès de l'établissement ou de l'Éducation nationale.
